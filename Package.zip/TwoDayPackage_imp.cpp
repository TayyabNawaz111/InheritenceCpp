#include "TwoDayPackage.h"
TwoDayPackage::TwoDayPackage(){
	Flatfee = 0;
}
TwoDayPackage::TwoDayPackage(double Flatfee,
	string Sname, string Saddress, string Scity,
	string Sstate, string Rname, string Raddress, string  Rcity,
	string Rstate, int cZIP_code, int rZIP_code,
	double weight_in_ounces, double cost_per_ounce) :Package
	(Sname, Saddress, Scity,
	Sstate, Rname, Raddress, Rcity,
	Rstate, cZIP_code, rZIP_code,
	weight_in_ounces, cost_per_ounce)
{
	if (Flatfee > 0){
		this->Flatfee = Flatfee;
	}
	else{
		this->Flatfee = 0;
	}
}
double TwoDayPackage::calculateCost(){
	return (Package::calculateCost() + this->Flatfee);
}