#include "Package.h"
Package::Package(){
	Sname = "";
	Saddress = "";
	Scity = "";
	Sstate = "";
	Rname = "";
	Raddress = "";
	Rcity = "";
	Rstate = "";
	cZIP_code = 0;
	rZIP_code = 0;
	weight_in_ounces = 0;
	cost_per_ounce = 0;
}
Package::Package(string Sname, string Saddress, string Scity,
	string Sstate, string Rname, string Raddress, string  Rcity,
	string Rstate, int cZIP_code, int rZIP_code,
	double weight_in_ounces, double cost_per_ounce)
{
	this->Sname = Sname;
	this->Saddress = Saddress;
	this->Scity = Scity;
	this->Sstate = Sstate;
	this->Rname = Rname;
	this->Raddress = Raddress;
	this->Rcity = Rcity;
	this->Rstate = Rstate;
	this->cZIP_code = cZIP_code;
	this->rZIP_code = rZIP_code;
	if (weight_in_ounces > 0){
		this->weight_in_ounces = weight_in_ounces;
	}
	else
	{
		this->weight_in_ounces = 0;
	}
	if (cost_per_ounce > 0){
		this->cost_per_ounce = cost_per_ounce;
	}
	else{
		this->cost_per_ounce = 0;
	}
}

double Package::calculateCost(){
	return (this->weight_in_ounces*this->cost_per_ounce);
}
double Package::get_weight(){
	return this->weight_in_ounces;
}