
#include "OverNightPackage.h"
#include "TwoDayPackage.h"
int main(){
	TwoDayPackage p1(200, "Ubaid", "Satellite Town", "Lahore", "Punjab", "Tayyab", "Mustafa Town", "Lahore", "Punjab", 1, 2, 15, 5.9);
	cout << "TwoDayPackage Cost: " << p1.calculateCost() << endl;
	cout << "----------------------------\n";
	OverNightPackage p2(15, "Usama", "PU", "Lahore", "Punjab", "Tayyab Nawaz", "Mall Road", "Lahore", "Punjab", 5, 21, 10, 8.99); 
	cout << "OverNightPackage Cost: " << p2.calculateCost() << endl;
	cout << "----------------------------\n";
	system("pause");
	return 0;
}