#ifndef PACKAGE_H
#define PACKAGE_H
#include <iostream>
#include <string>
using namespace std;
#pragma warning(disable:4996)
class Package{
	string Sname, Saddress, Scity, Sstate, Rname, Raddress, Rcity, Rstate;
	int cZIP_code,rZIP_code;
	double weight_in_ounces, cost_per_ounce;
public:
	Package();
	Package(string Sname, string Saddress, string Scity,
		string Sstate, string Rname, string Raddress, string  Rcity,
		string Rstate, int cZIP_code, int rZIP_code,
		double weight_in_ounces, double cost_per_ounce);
	double calculateCost();
	double get_weight();
};
#endif