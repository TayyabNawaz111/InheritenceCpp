#ifndef OVERNIGHTPACKAGE_H
#define OVERNIGHTPACKAGE_H
#include "Package.h"
class OverNightPackage :public Package{
	double additional_fee;
public:
	OverNightPackage();
	OverNightPackage(double additional_fee,string Sname, string Saddress, string Scity,
		string Sstate, string Rname, string Raddress, string  Rcity,
		string Rstate, int cZIP_code, int rZIP_code,
		double weight_in_ounces, double cost_per_ounce);
	double calculateCost();
};
#endif