#include "OverNightPackage.h"
OverNightPackage::OverNightPackage(){
	this->additional_fee = 0;
}
OverNightPackage::OverNightPackage(double additional_fee,string Sname, string Saddress, string Scity,
	string Sstate, string Rname, string Raddress, string  Rcity,
	string Rstate, int cZIP_code, int rZIP_code,
	double weight_in_ounces, double cost_per_ounce)
	:Package(Sname, Saddress, Scity,
	Sstate, Rname, Raddress, Rcity,
	Rstate, cZIP_code, rZIP_code,
	weight_in_ounces, cost_per_ounce)
{

	if (additional_fee > 0){
		this->additional_fee = additional_fee;
	}
	else{
		this->additional_fee = 0;
	}
}
double OverNightPackage::calculateCost(){
	return ((this->additional_fee*this->get_weight()) + Package::calculateCost());
}