#ifndef TWODAYPACKAGE_H
#define TWODAYPACKAGE_H
#include "Package.h"
class TwoDayPackage :public Package{
	double Flatfee;
public:
	TwoDayPackage();
	TwoDayPackage(double Flatfee,
		string Sname, string Saddress, string Scity,
		string Sstate, string Rname, string Raddress, string  Rcity,
		string Rstate, int cZIP_code, int rZIP_code,
		double weight_in_ounces, double cost_per_ounce);
	double calculateCost();
};
#endif