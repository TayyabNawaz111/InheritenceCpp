#include"SavingsAccount.h"

void SavingsAccount::check()
{
	if (getBalance() < 25)
	{
		status = false;
	}
	else
		status = true;
}
void SavingsAccount::withdraw(double amount)
{
	if (status)
	{
			BankAccount::withdraw(amount);		
	}
	else
	{
		cout << "Balance is less than 25$.\n";
	}
}
void SavingsAccount::deposit(double amount)
{
	if (status)
	{
		BankAccount::deposit(amount);
	}
	else if (!status && amount > 25)
	{
		status = true;
		BankAccount::deposit(amount);
	}
}
void SavingsAccount::monthlyProc()
{
	if (getNOW() > 4 && status)
	{
		for (int i = 4; i < getNOW(); i++)
		{
			this->setMontlyServiceCharges(this->getMontlyServiceCharges() + 1);
		}
		BankAccount::monthlyProc();
		check();
		if (!status)
		{
			cout << "Account Inactive\n";
		}
	}
	else
	{
		BankAccount::monthlyProc();
		check();
		if (!status)
		{
			cout << "Account Inactive\n";
		}

	}

}
bool SavingsAccount::getStatus(){
	return this->status;
}