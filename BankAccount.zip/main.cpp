#include "SavingsAccount.h"
#include "CheckingAccount.h"

int main()
{
	cout << "MUHAMMAD TAYYAB NAWAZ L1S22BSSE0004\nUSAMA RASHEED L1S22BSSE0039\n";
	cout << "-----------------------------------------------\n";

	double dam, wam;
	SavingsAccount a;
	CheckingAccount b;
	BankAccount *sa[2];
	sa[0] = &a;
	sa[1] = &b;
	//SavingsAccount ki hai
	cout << "Savings Account:\n";
	cout << "Beginning Balance is: " << sa[0]->getBalance() << endl;
	cout << "Enter Deposit Amount for Saving Account: ";
	cin >> dam;
	sa[0]->deposit(dam);
	if (dam >= 25){
		cout << "Enter Withdrawal Amount for Saving Account: ";
		cin >> wam;
		sa[0]->withdraw(wam);

		cout << "Total Amount of Deposit: " << dam << endl;
		cout << "Total Amount of Withdrwal: " << wam << endl;

		sa[0]->setMontlyServiceCharges(15);
		cout << "Service Charges: " << sa[0]->getMontlyServiceCharges() << endl;
	}
	sa[0]->monthlyProc();
	if (a.getStatus())
	cout << "Ending Balance is: " << sa[0]->getBalance() << endl;
	cout << "-----------------------------------------------\n";
	//CheckingAccount ki hai
	cout << "Checking Account:\n";
	cout << "Beginning Balance is: " << sa[1]->getBalance() << endl;
	cout << "Enter Deposit Amount for Checking Account: ";
	cin >> dam;
	sa[1]->deposit(dam);
	cout << "Enter Withdrawal Amount for Checking Account: ";
	cin >> wam;
	sa[1]->withdraw(wam);
	cout << "Total Amount of Deposit: " << dam << endl;
	cout << "Total Amount of Withdrwal: " << wam << endl;
	sa[1]->setMontlyServiceCharges(15);
	sa[1]->monthlyProc();
	cout << "Ending Balance is: " << sa[1]->getBalance() << endl;
	cout << "-----------------------------------------------\n";
	system("pause");
	return 0;
}