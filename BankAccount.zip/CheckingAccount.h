#ifndef CA
#define CA
#include "BankAccount.h"
class CheckingAccount : public BankAccount
{
public:
	void withdraw(double amount);
	void monthlyProc();
};













#endif