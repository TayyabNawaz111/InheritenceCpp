#include "CheckingAccount.h"
void CheckingAccount::withdraw(double amount)
{
	if (amount > this->getBalance())
	{
		BankAccount::withdraw(amount);
		this->setMontlyServiceCharges(this->getMontlyServiceCharges() + 15);
		this->setBalance(this->getBalance() - this->getMontlyServiceCharges());
	}
	else
	{
		BankAccount::withdraw(amount);
	}
}

void CheckingAccount::monthlyProc()
{
	this->setMontlyServiceCharges(this->getMontlyServiceCharges() + 5 + (this->getNOW()*0.10));
	cout << "Service Charges: " << getMontlyServiceCharges() << endl;
	BankAccount::monthlyProc();
}