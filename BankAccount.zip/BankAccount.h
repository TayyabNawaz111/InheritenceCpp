#ifndef BA
#define BA
#include<iostream>
using namespace std;


class BankAccount
{
	double balance, iRate, monthlyServiceCharges;
	int noOfDeposits = 0, noOfWithdraw = 0;
public:
	BankAccount();
	BankAccount(double b, double iR, double msc);
	void setBalance(double b);
	void setInterestRate(double iR);
	void setMontlyServiceCharges(double c);
	void setNOD(int nod);
	void setNOW(int now);
	double getBalance();
	double getInterestRate();
	double getMontlyServiceCharges();
	int getNOD();
	int getNOW();
	virtual void deposit(double amount);
	virtual void withdraw(double amount);
	virtual void calcInt();
	virtual void monthlyProc();
	
};
#endif