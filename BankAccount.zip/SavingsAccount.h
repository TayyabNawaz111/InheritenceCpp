#ifndef SA
#define SA
#include"BankAccount.h"
class SavingsAccount : public BankAccount
{
	bool status=false;

public:
	bool getStatus();
	void check();
	void withdraw(double amount);
	void deposit(double amount);
	void monthlyProc();
};
#endif