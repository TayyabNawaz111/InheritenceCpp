#include"BankAccount.h"


BankAccount::BankAccount()
{
	balance = 0; 
	iRate = 0;
	monthlyServiceCharges = 0;
}
BankAccount::BankAccount(double b, double iR, double msc)
{
	this->setBalance(b);
	this->setInterestRate(iR);
	this->setMontlyServiceCharges(msc);

}
void BankAccount::setBalance(double b)
{
	
		this->balance = b;
	
	
}
void BankAccount::setInterestRate(double iR)
{
	if (iR >= 0)
	{
		this->iRate = iR;
	}
	else
	{
		this->iRate = 0;
	}
}
void BankAccount::deposit(double amount)
{
	this->setBalance(this->balance += amount);
	this->noOfDeposits++;
}
void BankAccount::withdraw(double amount)
{
	this->balance = balance - amount;
	this->noOfWithdraw++;
}
void BankAccount::calcInt()
{
	double mIR;
	mIR = (iRate / 12);
	mIR = balance*mIR;
	balance = balance + mIR;
}
void BankAccount::monthlyProc()
{
	this->balance -= monthlyServiceCharges;
	calcInt();
	this->noOfWithdraw = 0;
	this->noOfDeposits = 0;
	this->monthlyServiceCharges = 0;
}
double BankAccount::getBalance()
{
	return this->balance;
}
double BankAccount::getInterestRate()
{
	return this->iRate;
}
double BankAccount::getMontlyServiceCharges(){
	return this->monthlyServiceCharges;
}
void BankAccount::setMontlyServiceCharges(double c)
{
	
	this->monthlyServiceCharges = c;

}
int BankAccount::getNOD()
{
	return this->noOfDeposits;
}
int BankAccount::getNOW()
{
	return this->noOfWithdraw;
}
void BankAccount::setNOD(int nod)
{
	this->noOfDeposits = nod;
}
void BankAccount::setNOW(int now)
{
	this->noOfWithdraw = now;
}
